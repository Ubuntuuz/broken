# quang
setup
pip install requests pysocks 
git clone https://github.com/Quangtd123/quang 
cd quang 
python quang.py
